@echo off
cd /d "%~dp0"
"RoadFighter-2160x1440.exe"
