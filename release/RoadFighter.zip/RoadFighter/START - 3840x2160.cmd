@echo off
cd /d "%~dp0"
"RoadFighter-3840x2160.exe"
