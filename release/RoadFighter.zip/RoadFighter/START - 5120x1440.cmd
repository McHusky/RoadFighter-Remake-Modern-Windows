@echo off
cd /d "%~dp0"
"RoadFighter-5120x1440.exe"
