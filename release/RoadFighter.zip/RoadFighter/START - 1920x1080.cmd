@echo off
cd /d "%~dp0"
"RoadFighter-1920x1080.exe"
